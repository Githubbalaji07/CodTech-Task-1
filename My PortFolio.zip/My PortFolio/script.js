
// document.querySelector("form").addEventListener("submit",async(e)=>{

//     e.preventDefault();

//     const formData={
//         Name:document.querySelector("input[name='Name']").value,
//         Email:document.querySelector("input[name='Email']").value,
//         Message:document.querySelector("textarea[name='Message']").value
//     };

//     try{

//         const response=await fetch("/api/form/submit",{
//             method:"POST",
//             headers:{
//                 "content-Type":"application/json"
//             },
//             body:JSON.stringify(formData)
//         });

//         if(response.ok){
//             alert("Response Submitted Sucessfully");
//             this.reset();
//         }else{
//             const errorData=await response.json();
//             alert("Failed To Submit Response "+errorData.Message);
//         }
//     }catch(error){
//         console.error("Error Submiting Response ",error);
//     }

// });

